"""CANable 2.5 USB-CAN adapter driver (ElmueSoft protocol).

Main entrypoint: ZDTCanable class.
"""
from __future__ import annotations

import logging
import struct
import threading
import time
from typing import Callable, List, Optional

import usb.core
import usb.util

from .constants import (
    CANABLE_VID, CANABLE_PID, EP_IN, EP_OUT, MAX_PACKET_SIZE,
    HOST_FORMAT_MAGIC, LEGACY_FRAME_SIZE,
    GS_ReqSetHostFormat, GS_ReqSetBitTiming, GS_ReqSetDeviceMode,
    GS_ReqGetCapabilities, GS_ReqGetDeviceVersion, GS_ReqGetTimestamp,
    GS_ReqIdentify, GS_ReqSetBitTimingFD, GS_ReqGetCapabilitiesFD,
    GS_ReqSetTermination, GS_ReqGetTermination,
    ELM_ReqGetBoardInfo, ELM_ReqSetFilter, ELM_ReqGetLastError,
    ELM_ReqSetBusLoadReport, ELM_ReqSetPinStatus, ELM_ReqGetPinStatus,
    GS_DevFlagListenOnly, GS_DevFlagLoopback, GS_DevFlagOneShot,
    GS_DevFlagTimestamp, GS_DevFlagIdentify, GS_DevFlagCAN_FD,
    GS_DevFlagBitTimingFD, GS_DevFlagTermination,
    ELM_DevFlagProtocolElmue, ELM_DevFlagDisableTxEcho,
    GS_ModeStart, GS_TerminationON, GS_TerminationOFF,
    FIL_ClearAll, FIL_AcceptMask11bit, FIL_AcceptMask29bit,
    PINOP_Reset, PINOP_Set, PINOP_Tristate, PINOP_PullDown,
    PINOP_PullUp, PINOP_Disable, PINOP_Enable,
    PINID_BOOT0, PINST_High, PINST_Enabled,
    FEEDBACK_NAMES,
    logger,
)
from .bitrate import NOMINAL_BITTIMING, DATA_BITTIMING
from .frame import CANFrame
from .protocol import _ElmueProtocol


class ZDTCanable:
    def __init__(self, vid=None, pid=None, serial=None, port=None, backend=None):
        self.vid    = vid or CANABLE_VID
        self.pid    = pid or CANABLE_PID
        self.serial = serial
        self.dev:    Optional[usb.core.Device] = None
        self.ep_out: Optional[usb.core.Endpoint] = None
        self.ep_in:  Optional[usb.core.Endpoint] = None

        self._lock       = threading.Lock()
        self._running    = False
        self._fd_mode    = False
        self._bitrate:   Optional[int] = None
        self._sample_point: Optional[float] = None
        self._data_bitrate: Optional[int] = None
        self._data_sample_point: Optional[float] = None
        self._capabilities: int = 0
        self._capabilities_fd: int = 0
        self._protocol:  Optional[str] = None
        self._parser:    Optional[_ElmueProtocol] = None
        self._marker_counter: int = 0
        self._has_timestamp: bool = False
        self._listen_only: bool = False
        self._loopback: bool = False
        self._callbacks: List[Callable[[CANFrame], None]] = []
        self._overflow_cb: Optional[Callable[[], None]] = None
        self._last_error_info: Optional[str] = None
        self._tx_blocked_until: float = 0.0

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    @property
    def running(self) -> bool:
        return self._running

    @property
    def fd_mode(self) -> bool:
        return self._fd_mode

    @fd_mode.setter
    def fd_mode(self, value: bool):
        self._fd_mode = value

    # ================================================================
    #  Device enumeration
    # ================================================================
    @staticmethod
    def list_devices() -> List[dict]:
        devs = []
        for d in usb.core.find(find_all=True, idVendor=CANABLE_VID, idProduct=CANABLE_PID):
            try:
                mfg = usb.util.get_string(d, d.iManufacturer) or ""
                prd = usb.util.get_string(d, d.iProduct) or ""
                ser = usb.util.get_string(d, d.iSerialNumber) or ""
            except Exception:
                mfg = prd = ser = ""
            devs.append({
                "backend": "elmue",
                "vid": CANABLE_VID, "pid": CANABLE_PID,
                "manufacturer": mfg, "product": prd, "serial": ser,
                "path": None,
            })
        return devs

    # ================================================================
    #  Connection & disconnection
    # ================================================================
    def open(self):
        kwargs = dict(idVendor=self.vid, idProduct=self.pid)
        if self.serial:
            kwargs.setdefault("serial_number", self.serial)
        logger.debug("查找设备: VID=0x%04X PID=0x%04X", self.vid, self.pid)
        self.dev = usb.core.find(**kwargs)
        if self.dev is None:
            raise RuntimeError(f"CANable not found (VID=0x{self.vid:04X}, PID=0x{self.pid:04X})")

        # 获取设备序列号用于日志追踪
        try:
            sn = usb.util.get_string(self.dev, self.dev.iSerialNumber)
            logger.info("设备已打开: serial=%s", sn)
        except Exception:
            logger.info("设备已打开: serial=<unknown>")

        self._setup_usb()
        self._init_device()
        self._detect_protocol()
        logger.debug("协议检测完成: protocol=%s", self._protocol.__class__.__name__)

    def close(self):
        logger.debug("关闭设备")
        if self._running:
            try:
                self.stop()
            except Exception:
                pass
        # 关闭 LED 识别（非关键操作，短超时避免阻塞断开）
        try:
            self._ctrl_out(GS_ReqIdentify, data=struct.pack('<I', 0), timeout=100)
        except Exception:
            pass
        if self.dev is not None:
            try:
                usb.util.dispose_resources(self.dev)
            except Exception:
                pass
            self.dev = None
        self.ep_in = self.ep_out = None
        self._running = False

    def _setup_usb(self):
        try:
            if self.dev.is_kernel_driver_active(0):
                self.dev.detach_kernel_driver(0)
        except (usb.core.USBError, NotImplementedError):
            pass

        try:
            self.dev.set_configuration()
        except usb.core.USBError:
            pass
        cfg = self.dev.get_active_configuration()
        intf = cfg[(0, 0)]

        self.ep_in = usb.util.find_descriptor(
            intf, custom_match=lambda e: e.bEndpointAddress == EP_IN)
        self.ep_out = usb.util.find_descriptor(
            intf, custom_match=lambda e: e.bEndpointAddress == EP_OUT)

        if self.ep_out is None:
            self.ep_out = usb.util.find_descriptor(
                intf, custom_match=lambda e: usb.util.endpoint_direction(e.bEndpointAddress)
                                               == usb.util.ENDPOINT_OUT)
        if self.ep_in is None:
            self.ep_in = usb.util.find_descriptor(
                intf, custom_match=lambda e: usb.util.endpoint_direction(e.bEndpointAddress)
                                               == usb.util.ENDPOINT_IN)

        if self.ep_out is None or self.ep_in is None:
            raise RuntimeError(f"USB endpoints not found (need EP_IN=0x81, EP_OUT=0x02)")

    def _init_device(self):
        self._reset_device()

        self._ctrl_out_checked(GS_ReqSetHostFormat,
                               data=struct.pack('<I', HOST_FORMAT_MAGIC))

        caps = self._ctrl_in(GS_ReqGetCapabilities, length=44)
        if caps and len(caps) >= 4:
            self._capabilities = struct.unpack_from('<I', bytes(caps), 0)[0]
            logger.info("capabilities: 0x%X", self._capabilities)

        ver = self._ctrl_in(GS_ReqGetDeviceVersion, length=16)
        if ver and len(ver) >= 12:
            sw = struct.unpack_from('<I', bytes(ver), 4)[0]
            hw = struct.unpack_from('<I', bytes(ver), 8)[0]
            logger.info("firmware: 0x%08X, hardware: 0x%08X", sw, hw)

    def _reset_device(self):
        flags = ELM_DevFlagProtocolElmue
        try:
            self._ctrl_out(GS_ReqSetDeviceMode,
                           data=struct.pack('<II', 0, flags))
            time.sleep(0.05)
        except usb.core.USBError:
            logger.debug("RESET failed (device may already be closed)")

    def _detect_protocol(self):
        if self._capabilities & ELM_DevFlagProtocolElmue:
            self._protocol = "elmue"
            self._parser = _ElmueProtocol()
            logger.info("using ElmueSoft variable-length protocol")
        else:
            self._protocol = "legacy"
            self._parser = None
            logger.info("using Legacy fixed-length protocol (80 bytes)")

    # ================================================================
    #  USB control transfers
    # ================================================================
    def _ctrl_out(self, req, value=0, index=0, data=None, timeout=1000):
        bmRequestType = (usb.util.CTRL_OUT
                         | usb.util.CTRL_TYPE_VENDOR
                         | usb.util.CTRL_RECIPIENT_INTERFACE)
        if data is None:
            data = []
        return self.dev.ctrl_transfer(bmRequestType, req, value, index, data, timeout)

    def _ctrl_in(self, req, value=0, index=0, length=64, timeout=1000):
        bmRequestType = (usb.util.CTRL_IN
                         | usb.util.CTRL_TYPE_VENDOR
                         | usb.util.CTRL_RECIPIENT_INTERFACE)
        return self.dev.ctrl_transfer(bmRequestType, req, value, index, length, timeout)

    def _ctrl_out_checked(self, req, value=0, index=0, data=None, timeout=1000):
        self._ctrl_out(req, value, index, data, timeout)
        return self._check_last_error()

    def _check_last_error(self) -> Optional[int]:
        try:
            result = self._ctrl_in(ELM_ReqGetLastError, length=1)
            if result and len(result) >= 1:
                feedback = result[0]
                if feedback != 0 and feedback != 2:
                    name = FEEDBACK_NAMES.get(feedback, f"unknown({feedback})")
                    logger.warning("control request failed: eFeedback=%d (%s)", feedback, name)
                    return feedback
        except usb.core.USBError:
            pass
        return None

    # ================================================================
    #  CAN controller lifecycle
    # ================================================================
    def start(self, loopback: bool = False, disable_echo: bool = False, one_shot: bool = False):
        flags = 0
        if self._protocol == "elmue":
            flags |= ELM_DevFlagProtocolElmue

        if self._listen_only:
            flags |= GS_DevFlagListenOnly

        if loopback or self._loopback:
            flags |= GS_DevFlagLoopback

        if one_shot:
            flags |= GS_DevFlagOneShot

        if disable_echo:
            flags |= ELM_DevFlagDisableTxEcho

        if self._fd_mode:
            flags |= GS_DevFlagCAN_FD

        payload = struct.pack('<II', GS_ModeStart, flags)
        self._ctrl_out_checked(GS_ReqSetDeviceMode, data=payload)

        self._has_timestamp = bool(flags & GS_DevFlagTimestamp)
        if self._parser and isinstance(self._parser, _ElmueProtocol):
            self._parser.set_timestamp_mode(self._has_timestamp)

        self._running = True
        time.sleep(0.05)  # allow transceiver/isolator to power up
        logger.info("CAN started (protocol=%s, FD=%s, loopback=%s, flags=0x%X, bitrate=%s, data_bitrate=%s)",
                    self._protocol, self._fd_mode, bool(flags & GS_DevFlagLoopback),
                    flags, self._bitrate, self._data_bitrate)

    def stop(self):
        flags = 0
        if self._protocol == "elmue":
            flags |= ELM_DevFlagProtocolElmue
        try:
            self._ctrl_out_checked(GS_ReqSetDeviceMode,
                                   data=struct.pack('<II', 0, flags))
        except usb.core.USBError as e:
            logger.warning("stop USB error: %s", e)
        self._running = False
        logger.info("CAN stopped")

    def recover(self):
        flags = ELM_DevFlagProtocolElmue if self._protocol == "elmue" else 0
        self._ctrl_out(GS_ReqSetDeviceMode, data=struct.pack('<II', 0, flags))
        time.sleep(0.05)

        if self._parser is not None:
            self._parser.clear()

        try:
            for _ in range(16):
                self.ep_in.read(256, timeout=10)
        except usb.core.USBError:
            pass

        if self._bitrate:
            self.set_bitrate(self._bitrate, sample_point=self._sample_point)
        if self._fd_mode and self._data_bitrate:
            self.set_data_bitrate(self._data_bitrate, sample_point=self._data_sample_point)

        self.start(loopback=self._loopback)
        self._tx_blocked_until = time.time() + 0.3
        logger.info("CAN recovered")

    # ================================================================
    #  Bit timing configuration
    # ================================================================
    def set_bitrate(self, bitrate: int, sample_point: float | None = None):
        if sample_point is None:
            if bitrate not in NOMINAL_BITTIMING:
                brp, seg1, seg2, sjw = self._calc_bitrate_params(bitrate)
            else:
                brp, seg1, seg2, sjw = NOMINAL_BITTIMING[bitrate]
        else:
            brp, seg1, seg2, sjw = self._calc_bitrate_params(
                bitrate, sample_point=sample_point)

        prop = 0
        payload = struct.pack('<IIIII', prop, seg1, seg2, sjw, brp)
        self._ctrl_out_checked(GS_ReqSetBitTiming, data=payload)
        self._bitrate = bitrate
        self._sample_point = sample_point
        sample_pct = (1 + seg1) / (1 + seg1 + seg2) * 100
        logger.info("nominal bitrate set: %d bps (brp=%d seg1=%d seg2=%d sjw=%d sample=%.1f%%)",
                    bitrate, brp, seg1, seg2, sjw, sample_pct)

    def set_data_bitrate(self, data_bitrate: int, sample_point: float | None = None):
        # 8Mbps 数据段固件要求固定 50% 采样点，不参与可调
        if sample_point is None or data_bitrate == 8_000_000:
            if data_bitrate not in DATA_BITTIMING:
                brp, seg1, seg2, sjw = self._calc_bitrate_params(data_bitrate, data_phase=True)
            else:
                brp, seg1, seg2, sjw = DATA_BITTIMING[data_bitrate]
        else:
            brp, seg1, seg2, sjw = self._calc_bitrate_params(
                data_bitrate, data_phase=True, sample_point=sample_point)

        prop = 0
        payload = struct.pack('<IIIII', prop, seg1, seg2, sjw, brp)
        self._ctrl_out_checked(GS_ReqSetBitTimingFD, data=payload)
        self._data_bitrate = data_bitrate
        self._data_sample_point = sample_point
        sample_pct = (1 + seg1) / (1 + seg1 + seg2) * 100
        logger.info("data bitrate set: %d bps (brp=%d seg1=%d seg2=%d sjw=%d sample=%.1f%%)",
                    data_bitrate, brp, seg1, seg2, sjw, sample_pct)

    def _calc_bitrate_params(self, bitrate: int, data_phase: bool = False,
                             sample_point: float | None = None):
        # STM32G4 FDCAN 数据相限制：TSEG1≤15, TSEG2≤15, SJW≤15, BRP≤32 (DBRP 5位)
        # 标称相限制较宽：TSEG1≤32, TSEG2≤16, BRP≤512 (NBRP 9位)
        seg1_max = 15 if data_phase else 32
        seg2_max = 15 if data_phase else 16
        brp_max  = 32 if data_phase else 512
        clock = 160_000_000

        if sample_point is None:
            best_err = float('inf')
            best = None
            for seg1 in range(1, seg1_max + 1):
                for seg2 in range(1, min(seg1 + 1, seg2_max + 1)):
                    total = 1 + seg1 + seg2
                    for brp in range(1, brp_max + 1):
                        calc = clock / brp / total
                        err = abs(calc - bitrate) / bitrate
                        if err < best_err:
                            best_err = err
                            best = (brp, seg1, seg2, min(seg2, 4))
                        if err < 0.001:
                            return best
            if best_err > 0.05:
                raise ValueError(f"cannot compute bit timing for {bitrate} bps (error {best_err:.1%})")
            return best

        # 指定采样点：在 TSEG1/TSEG2 限制内搜索最接近 (波特率, 采样点) 的时序
        # 同等精度下优先更大的 time quanta 总数，时序更稳健
        best_err = (float('inf'), float('inf'))
        best_total = -1
        best = None
        for seg1 in range(1, seg1_max + 1):
            for seg2 in range(1, seg2_max + 1):
                total = 1 + seg1 + seg2
                brp = int(round(clock / (total * bitrate)))
                if brp < 1 or brp > brp_max:
                    continue
                calc = clock / (brp * total)
                rate_err = abs(calc - bitrate) / bitrate
                if rate_err > 0.01:
                    continue
                sample_err = abs((1 + seg1) / total - sample_point)
                key = (rate_err, sample_err)
                if key < best_err or (key == best_err and total > best_total):
                    best_err = key
                    best_total = total
                    best = (brp, seg1, seg2, min(seg2, 4))
        if best is None:
            raise ValueError(f"cannot compute bit timing for {bitrate} bps")
        return best

    # ================================================================
    #  Send / Receive
    # ================================================================
    def send(self, frame: CANFrame, timeout: int = 1000):
        if not self._running:
            raise RuntimeError("CAN not started")

        now = time.time()
        if now < self._tx_blocked_until:
            raise RuntimeError("CAN recovering, please wait")

        if self._protocol == "elmue":
            self._marker_counter = (self._marker_counter + 1) & 0xFF
            if self._marker_counter == 0:
                self._marker_counter = 1
            marker = self._marker_counter
            raw = frame.to_elmue_bytes(marker=marker)
            if self._parser and isinstance(self._parser, _ElmueProtocol):
                self._parser.store_tx_frame(marker, frame)
        else:
            raw = frame.to_legacy_bytes()

        try:
            with self._lock:
                self.ep_out.write(raw, timeout=timeout)
                if len(raw) > 0 and len(raw) % MAX_PACKET_SIZE == 0:
                    self.ep_out.write(b'', timeout=timeout)
        except usb.core.USBError as e:
            if getattr(e, 'errno', None) in (32, 232) or 'pipe' in str(e).lower():
                logger.warning("USB pipe error, clearing STALL")
                try:
                    usb.util.clear_stall(self.ep_out)
                except Exception:
                    pass
                self.recover()
                self._tx_blocked_until = time.time() + 0.5
            raise

    def send_periodic(self, frame: CANFrame, interval_s: float = 0.01, count: int = 0):
        sent = 0
        while count == 0 or sent < count:
            self.send(frame)
            sent += 1
            if count == 0 or sent < count:
                time.sleep(interval_s)

    def receive(self, timeout: float = 1.0) -> Optional[CANFrame]:
        if not self._running:
            raise RuntimeError("CAN not started")

        if self._protocol == "elmue":
            return self._recv_elmue(timeout)
        else:
            return self._recv_legacy(timeout)

    def _recv_elmue(self, timeout: float = 1.0) -> Optional[CANFrame]:
        if self._parser is not None:
            frames = self._parser.flush_frames()
            if frames:
                return self._take_first_frame(frames)

        try:
            data = self.ep_in.read(256, timeout=int(timeout * 1000))
        except usb.core.USBError as e:
            errno = getattr(e, "errno", None)
            if errno in (110, 10060) or "timeout" in str(e).lower():
                return None
            if errno in (75, 121) or "overflow" in str(e).lower():
                logger.debug("USB overflow, flushing endpoint buffer")
                try:
                    self.ep_in.read(256, timeout=10)
                except Exception:
                    pass
                if self._overflow_cb:
                    try:
                        self._overflow_cb()
                    except Exception:
                        logger.exception("overflow callback failed")
                return None
            raise

        if not data:
            return None

        raw = bytes(data)
        frames = self._parser.feed(raw)

        return self._take_first_frame(frames)

    def _take_first_frame(self, frames: list) -> Optional[CANFrame]:
        """Return first frame, push the rest to pending buffer."""
        if not frames:
            return None
        if len(frames) > 1:
            self._parser.push_pending(frames[1:])
        return frames[0]

    def _recv_legacy(self, timeout: float = 1.0) -> Optional[CANFrame]:
        try:
            data = self.ep_in.read(LEGACY_FRAME_SIZE, timeout=int(timeout * 1000))
        except usb.core.USBError as e:
            errno = getattr(e, "errno", None)
            if errno in (110, 10060) or "timeout" in str(e).lower():
                return None
            if errno in (75, 121) or "overflow" in str(e).lower():
                try:
                    self.ep_in.read(LEGACY_FRAME_SIZE, timeout=10)
                except Exception:
                    pass
                return None
            raise

        if not data:
            return None

        return CANFrame.from_legacy_bytes(bytes(data))

    # ================================================================
    #  Feature queries & settings
    # ================================================================
    def check_fd_support(self) -> bool:
        try:
            caps_fd = self._ctrl_in(GS_ReqGetCapabilitiesFD, length=72)
            if caps_fd and len(caps_fd) >= 4:
                self._capabilities_fd = struct.unpack_from('<I', bytes(caps_fd), 0)[0]
        except usb.core.USBError:
            pass

        fd_supported = bool((self._capabilities | self._capabilities_fd) & GS_DevFlagCAN_FD)
        fd_timing = bool((self._capabilities | self._capabilities_fd) & GS_DevFlagBitTimingFD)
        supported = fd_supported and fd_timing
        logger.info("FD support: %s (caps=0x%X, caps_fd=0x%X)",
                    supported, self._capabilities, self._capabilities_fd)
        return supported

    def get_version(self) -> Optional[str]:
        """Return firmware version as human-readable string (e.g. '25.10.23')."""
        try:
            ver = self._ctrl_in(GS_ReqGetDeviceVersion, length=16)
            if ver and len(ver) >= 12:
                sw = struct.unpack_from('<I', bytes(ver), 4)[0]
                hw = struct.unpack_from('<I', bytes(ver), 8)[0]
                # BCD format: 0x251023 → "25.10.23"
                major = (sw >> 16) & 0xFF
                minor = (sw >> 8) & 0xFF
                patch = sw & 0xFF
                return f"{major}.{minor:02d}.{patch:02d} (fw=0x{sw:08X}, hw=0x{hw:08X})"
        except usb.core.USBError:
            pass
        return None

    def read_error_register(self) -> Optional[str]:
        return self._last_error_info

    def identify(self, duration_ms: int = 1000):
        try:
            self._ctrl_out(GS_ReqIdentify, data=struct.pack('<I', 1))
            time.sleep(duration_ms / 1000.0)
            self._ctrl_out(GS_ReqIdentify, data=struct.pack('<I', 0))
            time.sleep(0.02)
        except usb.core.USBError:
            pass

    def set_silent(self, enable: bool) -> bool:
        was_running = self._running
        if was_running:
            self.stop()
        self._listen_only = enable
        if was_running:
            self.start()
        return True

    # ================================================================
    #  Extended features
    # ================================================================
    def set_filter(self, operation: int = 0, can_id: int = 0, mask: int = 0):
        """Set hardware acceptance filter.

        Args:
            operation: FIL_ClearAll (0), FIL_AcceptMask11bit (1), or FIL_AcceptMask29bit (2).
            can_id: Filter value (e.g. 0x7E0). Ignored for FIL_ClearAll.
            mask: Mask value (e.g. 0x7FF). Ignored for FIL_ClearAll.
        """
        payload = struct.pack('<BIIII', operation, can_id, mask, 0, 0)
        self._ctrl_out_checked(ELM_ReqSetFilter, data=payload)
        logger.info("filter set: op=%d id=0x%X mask=0x%X", operation, can_id, mask)

    def clear_filters(self):
        """Remove all hardware acceptance filters."""
        self.set_filter(FIL_ClearAll)

    def get_termination(self) -> Optional[bool]:
        try:
            result = self._ctrl_in(GS_ReqGetTermination, length=4)
            if result and len(result) >= 4:
                return bool(struct.unpack_from('<I', bytes(result), 0)[0])
        except usb.core.USBError:
            pass
        return None

    def set_termination(self, enabled: bool):
        payload = struct.pack('<I', 1 if enabled else 0)
        self._ctrl_out_checked(GS_ReqSetTermination, data=payload)
        logger.info("termination: %s", "ON" if enabled else "OFF")

    def set_bus_load_report(self, interval: int = 0):
        """Enable periodic bus load report.

        Args:
            interval: Report interval in 0=off, 1..255=interval unit.
        """
        payload = struct.pack('<B', interval)
        self._ctrl_out_checked(ELM_ReqSetBusLoadReport, data=payload)

    def get_board_info(self) -> Optional[dict]:
        """Return board information (MCU name, board name, device ID)."""
        try:
            result = self._ctrl_in(ELM_ReqGetBoardInfo, length=55)
            if result and len(result) >= 6:
                raw = bytes(result)
                mcu_id = struct.unpack_from('<H', raw, 0)[0]
                # Two 25-char null-terminated strings at offset 2 and 27
                mcu_name = raw[2:27].split(b'\x00', 1)[0].decode('ascii', errors='replace')
                board_name = raw[27:52].split(b'\x00', 1)[0].decode('ascii', errors='replace')
                return {
                    "mcu_device_id": f"0x{mcu_id:03X}",
                    "mcu_name": mcu_name,
                    "board_name": board_name,
                }
        except usb.core.USBError:
            pass
        return None

    def get_timestamp(self) -> Optional[int]:
        """Return firmware 1μs precision timestamp (rolls over after ~1 hour)."""
        try:
            result = self._ctrl_in(GS_ReqGetTimestamp, length=4)
            if result and len(result) >= 4:
                return struct.unpack_from('<I', bytes(result), 0)[0]
        except usb.core.USBError:
            pass
        return None

    def set_pin_status(self, pin_id: int, operation: int):
        """Control a processor pin.

        Args:
            pin_id: ePinID constant (e.g. PINID_BOOT0=1).
            operation: ePinOperation constant (PINOP_Reset/Set/Tristate/etc.).
        """
        payload = struct.pack('<HHII', operation, pin_id, 0, 0)
        self._ctrl_out_checked(ELM_ReqSetPinStatus, data=payload)
        logger.info("pin %d: operation=%d", pin_id, operation)

    def get_pin_status(self, pin_id: int) -> Optional[int]:
        """Read a processor pin status.

        Args:
            pin_id: ePinID constant (e.g. PINID_BOOT0=1).

        Returns:
            Bit flags: PINST_High (0x01), PINST_Enabled (0x02), or None on error.
        """
        try:
            result = self._ctrl_in(ELM_ReqGetPinStatus, value=pin_id, length=2)
            if result and len(result) >= 2:
                return struct.unpack_from('<H', bytes(result), 0)[0]
        except usb.core.USBError:
            pass
        return None

    # ================================================================
    #  Callbacks & listening
    # ================================================================
    def on_receive(self, callback: Callable[[CANFrame], None]):
        self._callbacks.append(callback)

    def on_overflow(self, callback: Callable[[], None]):
        self._overflow_cb = callback

    def start_listening(self):
        self._running = True
        self._recv_thr = threading.Thread(target=self._listen_loop, daemon=True)
        self._recv_thr.start()

    def _listen_loop(self):
        while self._running:
            try:
                frame = self.receive(timeout=0.1)
                if frame is not None:
                    for cb in self._callbacks:
                        try:
                            cb(frame)
                        except Exception:
                            pass
            except Exception as e:
                if self._running:
                    logger.warning("receive error: %s", e)
                time.sleep(0.01)
